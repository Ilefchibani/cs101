#include <stdio.h>
#include <stdlib.h>

int main()
{
    int year;
    printf("year :");
    scanf("%d ,&year");

    if (year % 4 != 0){
        printf("%d common year\n",year);

    }
    else {
        if (year % 100 != 0){
            printf("%d leap year\n",year);
        }
        else{
            if(year % 400 != 0){
            printf("%d common year\n",year);
            }
            else{
                printf("%d leap year\n",year);
            }

    }


}
    return 0;

}

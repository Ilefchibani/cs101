#include <stdio.h>
#include <stdlib.h>
//help farm manage his milk production
//the goal is to compute the average production of milk and what is the cow with higher production
//the program should promote the user to input the nbre of cows
//the program should ask the user to input details of each cow each one has an  ID and production
//display the average production and the id
//the user should input a nbre (++)
//the production of the week should be positive and less than 100



int main()
{
    int n = 0;
    int id  = 0;
    int hid =0;
    float cp =0;
    float tp =0;
    float avr=0;
    float highp=0;

    do {
        printf("Give the nber of cows: ");
        scanf("%d",&n);}
    while(n<=0);

    for ( int i=1; i<=n; i++ ){
        printf("give the id of cow n %d: ",i);
        scanf("%d",&id);
        do {
            printf("give the production of week of cow n %d ",i);
            scanf("%f",&cp);
        }while(cp<=0 || cp>100);
        tp+=cp;
        if (cp>highp){
            highp=cp;
            hid=id;
        }

    }
    avr=tp/n;
    printf("the highest production is: %f \n",highp );
    printf("the cow with highest product is: %i \n",hid );
    printf("the average of production is : %f \n",avr );



    return 0;
}

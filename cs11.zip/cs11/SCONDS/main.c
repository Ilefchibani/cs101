#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x=5000;
    y=x/3600;
    r=x%3600;
    z=r/60;
    p=r%60;



    printf("y : %d\n", x );
    printf("z : %d\n", z );
    printf("p : %d\n", p );
    return 0;
}

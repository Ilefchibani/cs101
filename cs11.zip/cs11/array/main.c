#include <stdio.h>
#include <stdlib.h>

int main()
{
    int(arr[5]);
    int larg=0;
    for (int i=0;i<=5;i++){
        printf("element-[%d]",i);


    }








    printf("Hello world!\n");
    return 0;
}

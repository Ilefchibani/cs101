#include <stdio.h>
#include <stdlib.h>

int main()
{
    int c;
    scanf("%c",&c);
    printf("c=%i\n",c);






    return 0;
}

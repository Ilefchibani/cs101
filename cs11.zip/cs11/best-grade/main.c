#include <stdio.h>


int main()
{   float max=0;
    int n=0;
    float grade=0;

    printf("input the number of student: ",n);
    scanf("%d",&n );
    for (float i=0 ; i<=n ;i++){
            printf("input the grade of student: ",grade);
            scanf("%f",&grade );
            if (grade>100){
            printf("wrong grade!!!");
            }else{
                if (grade>max){
                        max=grade;

          }
  }
}
    printf("the max grade is: %i",max);











    return 0;
}

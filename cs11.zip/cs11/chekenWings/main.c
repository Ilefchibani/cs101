#include <stdio.h>
#include <stdlib.h>

int read_nb_chicken(){
    int nb_chicken=0;
    printf("enter the number of chicken \n");
    scanf("%d",&nb_chicken);
    return nb_chicken;
    }
void compute_prod_per_year(int nb_chicken,float prod_per_day[],float prods_per_year[]){
    for(int i=0;i<nb_chicken;i++){
       prods_per_year[i]= prods_per_day[i]*365;

    }
void display_details(int nb_chicken,int ids[],float prod_per_day[],float prods_per_year[]){
    for(int i=0; i<nb_chicken;i++){
        printf("%d | %.2f | %.2f \n",ids[i],prods_per_day[i],prods_per_year[i]);
    }
}

int main()
{
    int nb_chicken=read_nb_chicken();
    int ids[100];
    float prods_per_day[100];

    for(int i=0;i<nb_chicken ;i++){
        printf("enter the id of the chicken \n");
        scanf("%d",&ids[i]);
        printf("Enter the production per day \n");
        scanf("%d",&prods_per_day[i]);
    }

    float prods_per_year[100];
    compute_prod_per_year( nb_chicken, prod_per_day, prods_per_year)

    display_details( nb_chicken, ids, prod_per_day, prods_per_year)














    return 0;
}

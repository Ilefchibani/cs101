#include <stdio.h>
#include <stdlib.h>

int main()
{
    float equ=0;
    float a =0 ;
    float b=0 ;
    char op ;
    printf("Enter the equation : \n");
    scanf("%f %c %f ", &a , &op , &b) ;

    switch (op){
        case '+':
            equ = a + b ;break;

        case '-':
            equ = a - b ;break;

        case '/':
            if (b!=0){
                    equ = a / b ; }
            else {
                printf("%f can't be 0 !!\n",b);
                }
            break;


        case '%':
            if(a==(int)a && b==(int)b){
                equ = ((int)a % (int)b) ;
            }else{
                printf("a and b have to be integers!!\n");
            }break;



        case '*':
            equ = a * b ;break;

        default:
            printf("Invalid operator! Please use +, -, * ,/ or %.\n");

    }

    printf("the result of %f %c %f = %f \n",a , op , b , equ );

    return 0;
}

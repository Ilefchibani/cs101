#include <stdio.h>
#include <stdlib.h>

int main()
{
    int ids[100];
    float milk_production[100];
    int nb_cows=0;
    int choice=0;
    float bestproduction=0;
    int id_best_cow=0;
    float worstproduction=0;
    int id_worst_cow=0;

    do{
        printf("1- add cows\n");
        printf("2- remove a cow by id \n");
        printf("3- average production\n");
        printf("4- id best cow \n");
        printf("5- id worst cow\n");
        printf("6- quit \n");


        printf("enter your choice: \n ");
        int choice=0;
        scanf("%i",choice);

        switch(choice){

            case 1:
                {//add cows
                int nb_cows_to_add=0;
                printf("enter the number of cows to be added: \n");
                scanf("%i",&nb_cows_to_add);

                for(int i=0;i<nb_cows_to_add;i++){
                    printf("enter the id of cow %d:  \n",i);
                    scanf("%d",&ids[i+nb_cows]);

                    printf("enter the milk production of cow %d:  \n",i);
                    scanf("%f",&milk_production[i+nb_cows]);
                }
                nb_cows+=nb_cows_to_add;


                }
            break;
            case 2:
                {//remove a cow by id

                }
            break;
            case 3:
                {//average production

                }
            break;
            case 4:
                {//id best cow
                for (int i=0;i<nb_cows;i++){
                    if (milk_production[i]>bestproduction ){
                        bestproduction=milk_production[i];
                        id_best_cow=ids[i];
                    }
                }
                printf("the best cow is %i with %f production ",id_best_cow,bestproduction);
                }
            break;
            case 5:
                {//id worst cow
                for (int i=0;i<nb_cows;i++){
                    if (milk_production[i]<milk_production[i+1] ){
                        worstproduction=milk_production[i];
                        id_worst_cow=ids[i];
                    }
                }
                printf("the worst cow is %i with %f production ",id_worst_cow,worstproduction);
                }

                }
            break;
            case 6:
                {
                printf("id   milk production\n");
                for (int i=0;i<nb_cows;i++){
                    printf("%d  %f\n",ids[i],milk_production[i]);

                }

                }
            break;
            case 7:{//display data

            }break;
            }
    }while(choice !=7);



    return 0;
}

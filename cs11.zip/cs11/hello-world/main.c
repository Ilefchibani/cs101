#include <stdio.h>

int main()
{
    int a = 100;
    float b =1.5;
    double c =a*b;

    printf("a=%i\n",a);
    printf("b=%g\n",b);
    printf("c=%lf\n",c);
    printf("%i * %g =%lg",a,b,c);


    int e = 10;
    int f = 3;
    float r = e/(float)f;
    printf("%i/%i =%f\n",e,f,r);
    int m = e%f;
    printf("%i mod %i =%i\n",e,f,m);



    return 0;
}

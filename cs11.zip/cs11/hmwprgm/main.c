#include <stdio.h>


int main()
{

    int day=0;
    int month=0;
    int year=0;
    printf("what's the day :\n");
    scanf("%d",&day );
    printf("what's the month :\n");
    scanf("%d",&month );
    printf("what's the year :\n");
    scanf("%d",&year );

    if(day>31){
        printf("wrong date:\n");
            month=00;
            day=00;
            year=0000;
        }
    else if(month>12){
        printf("wrong date!!!\n");
        }
    else{
        if  ( month==2 && day==29){
            month+=1;
            day=01;
        }
        else if (day==31 && month==12 ){
            month=01;
            day=01;
            year+=1;
        }
        else if (day==30 && (month==4 || month==6 || month==9 || month==11 ) ){
            month+=1;
            day=01;
        }
        else if (day==31 ){
            month+=1;
            day=01;
        }
        else{
            day+=1;
        }
       }
    printf("the Date is: %d/%d/%d \n",day,month,year);


    return 0;
}

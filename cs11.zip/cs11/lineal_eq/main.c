#include <stdio.h>
#include <stdlib.h>

float compute_solution (float a, float b)
{

    return -b/a ;
}

float read_input(char message[])
{
    printf("%s:\n",message);
    float z=0;
    scanf("%f",&z);

    return z;
}
void display_solution(float a, float b, float x )
{
  printf("the solution of %.2f * x + %.2f = 0 is %.2f \n",a,b,x);

}



int main()
{
    float a=read_input("enter a");

    float b=read_input("enter b");

    float x = compute_solution(a,b);

    display_solution(a,b,x);



    return 0;
}

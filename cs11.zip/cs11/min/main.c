#include <stdio.h>
#include <math.h>

int main()
{
    int x=0;
    int min=pow(2,31)-1;
    do{
        printf("enter x: ");
        scanf("%d",&x);
        if(x<min && x!=0){
            min=x;
        }
    }while(x=!0);
    printf("the min value is %d",min);















    return 0;
}

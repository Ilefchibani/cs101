#include <stdio.h>
#include <stdlib.h>

int main()
{

    for(int i=1000;i<10000;i++) {
        int units =(i%10);
        int tens =(i%100)/10;
        int handreds =(i%1000)/100;
        int thousends =(i/1000);
        if (units==thousends && tens==handreds){
            printf("The number %i is palindrome     \n",i);
        }

    }







    return 0;


}

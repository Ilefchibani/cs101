#include <stdio.h>
#include <stdlib.h>

int main()
{
    float grade=0;
    float ad = 0;
    printf("What's the grade of the student\n");
    scanf("%f",&grade);


    printf("the student grade is ");


    if ( grade>90){
        float ad = grade / 100 *(-1);
        grade += (float)ad ;
    }
    else if(grade>70){
        grade *= 1.05;

    }
    else if(grade<30){
        float ad= grade / 100 *(30);
        grade += (float)ad ;
    }

    else{
        grade=0;
    }

    printf("%f",grade);


    return 0;
}

#include <stdio.h>
#include <stdlib.h>
//we would like to manage a list of student with max capacity of 100
//each student has a name and grade
//max length of a name is 50 character

int main()
{

    char prof_name[50];
    printf("enter your name: \n");
    scanf("%s",prof_name );
    printf("welcome %s \n",prof_name);

    float grades[100];
    char names[100][50];
    int nb_students;
    printf("enter the number of students: \n");
    scanf("%d", nb_students );

    for(int i=0;i<nb_students;i++){
        printf("enter the student name: \n");
        scanf("%s",names[i]);
        printf("enter the student grade: \n");
        scanf("%f",&grades[i]);

        }
    int best_i;
    for (int i =0;i<nb;i++){
        if (grades[i]>best_i):
                best_i=i;
    }




    return 0;
}

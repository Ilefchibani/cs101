#include <stdio.h>
#include <stdlib.h>

int main()
{
    int ids[100];
    float milk_productions[100];
    int nb_cows=0;
    int choice=0;

    do{
        printf("1- add cows\n");
        printf("2- remove a cow by id\n");
        printf("3- average production\n");
        printf("4- id best cow\n");
        printf("5- id worst cow\n");
        printf("6- display data\n");
        printf("7- quit\n");

        printf("enter your choice:\n");
        scanf("%d",&choice);

        switch (choice){
        case 1:
            {
             //add cows
             int nb_cows_to_add=0;
             printf("enter the number of cows to be added:\n");
             scanf("%d",&nb_cows_to_add);

             for(int i=0;i<nb_cows_to_add;i++){
                printf("enter the id of the cow %d:",i);
                scanf("%d",&ids[i+nb_cows]);

                printf("enter the milk production of the cow %d:",i);
                scanf("%g",&milk_productions);
                }

             nb_cows+=nb_cows_to_add;

            }
            break;
        case 2:
            {
            //remove a cow by id
            }
            break;
        case 3:
            {
             //average production
            }
            break;
        case 4:
            {
             //id best cow
            }
            break;
        case 5:
            {
             //id worst cow
            }
            break;
        case 6:
            {
             //display data
             printf("id    milk production\n");
             for (int i=0;i<nb_cows;i++){
                printf("%d    %f\n",ids[i],milk_productions[i]);

             }
            }
            break;
        case 7:
            {
             //quit
            }

        }
    }while(choice != 7);




    return 0;
}

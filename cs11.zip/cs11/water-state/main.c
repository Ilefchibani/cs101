#include <stdio.h>
#include <stdlib.h>

int main()
{
    float temperature=0;
    printf("What's the temperature of the water\n");
    scanf("%f",&temperature);


    printf("Water state is ");
    if ( temperature>100){
        printf("steam\n");
    }else if(temperature<0){
        printf("ice\n");
    }else {
    printf("liquid\n");
    }













    return 0;
}
